import { test, expect } from "@playwright/test";

test.use({ viewport: { width: 1440, height: 900 }, reducedMotion: "no-preference" });

const snapType = (page: import("@playwright/test").Page) =>
  page.evaluate(() => getComputedStyle(document.documentElement).scrollSnapType);

test("homepage wheel approaches settle at sections and can leave in both directions", async ({ page }) => {
  await page.goto("/");
  await page.evaluate(() => document.fonts.ready);
  await expect.poll(() => snapType(page)).toBe("y proximity");
  await page.mouse.move(1420, 450);
  for (const id of ["summary", "views"]) {
    const section = page.locator(`#${id}`);
    const distance = await section.evaluate(el => el.getBoundingClientRect().top - 8 - 45);
    await page.mouse.wheel(0, distance);
    await expect.poll(async () => Math.abs((await section.boundingBox())!.y - 8)).toBeLessThan(2);
  }
  const before = await page.evaluate(() => scrollY);
  await page.mouse.wheel(0, 500);
  await expect.poll(() => page.evaluate(() => scrollY)).toBeGreaterThan(before + 100);
  const after = await page.evaluate(() => scrollY);
  await page.mouse.wheel(0, -600);
  await expect.poll(() => page.evaluate(() => scrollY)).toBeLessThan(after - 100);
  await page.keyboard.press("Control+End");
  await expect.poll(() => page.evaluate(() => document.documentElement.scrollHeight - innerHeight - scrollY)).toBeLessThan(2);
  await page.getByRole("link", { name: /BACK TO TOP/ }).click();
  await expect.poll(() => page.evaluate(() => scrollY)).toBeLessThan(2);
});

test("production anchor and expanded reading stay usable", async ({ page }) => {
  await page.goto("/#views");
  await page.locator('[data-control="operate"]').click();
  await page.getByRole("link", { name: "VIEW PRODUCTION", exact: true }).click();
  await expect(page).toHaveURL(/#production$/);
  await expect.poll(async () => Math.abs((await page.locator("#production").boundingBox())!.y - 8)).toBeLessThan(2);
  await page.getByRole("button", { name: /放大查看 Shot Builder/ }).click();
  await expect(page.locator("dialog[open]")).toBeVisible();
  await expect.poll(() => snapType(page)).toBe("none");
  await page.keyboard.press("Escape");
  await expect.poll(() => snapType(page)).toBe("y proximity");
  await page.locator("#views details summary").click();
  await expect.poll(() => snapType(page)).toBe("none");
  await page.locator("#views details summary").click();
  await expect.poll(() => snapType(page)).toBe("y proximity");
});

test("chapters, narrow screens and reduced motion do not inherit homepage snapping", async ({ page }) => {
  await page.goto("/");
  await page.getByRole("link", { name: "02 / 设计&创新", exact: true }).click();
  await expect(page).toHaveURL(/\/design-innovation\/$/);
  await expect.poll(() => snapType(page)).toBe("none");
  for (const route of ["/systematic-thinking/", "/contact/"]) {
    await page.goto(route);
    expect(await snapType(page)).toBe("none");
  }
  await page.goto("/");
  await page.setViewportSize({ width: 390, height: 844 });
  expect(await snapType(page)).toBe("none");
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.emulateMedia({ reducedMotion: "reduce" });
  expect(await snapType(page)).toBe("none");
  await page.emulateMedia({ reducedMotion: "no-preference" });
  await expect.poll(() => snapType(page)).toBe("y proximity");
});
